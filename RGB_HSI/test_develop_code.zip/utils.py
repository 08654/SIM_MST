import torch
import numpy as np
import argparse
import os
import torch.backends.cudnn as cudnn
from architecture import *
import math
from hsi_dataset import TrainDataset, ValidDataset
from torch.utils.data import DataLoader
import hdf5storage
import torch
import torch.nn as nn
import numpy as np
import numpy as np
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import structural_similarity as ssim
import torch.nn.functional as F
import torch
import torchvision.transforms.functional as F
from pytorch_msssim import ssim, ms_ssim, SSIM, MS_SSIM
from skimage.metrics import structural_similarity




def save_matv73(mat_name, var_name, var):
    hdf5storage.savemat(mat_name, {var_name: var}, format='7.3', store_python_metadata=True)

class AverageMeter(object):
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

class Loss_MRAE(nn.Module):
    def __init__(self):
        super(Loss_MRAE, self).__init__()

    def forward(self, outputs, label):
        assert outputs.shape == label.shape
        error = torch.abs(outputs - label) / label
        mrae = torch.mean(error.contiguous().view(-1))
        return mrae

class Loss_RMSE(nn.Module):
    def __init__(self):
        super(Loss_RMSE, self).__init__()

    def forward(self, outputs, label):
        assert outputs.shape == label.shape
        error = outputs-label
        sqrt_error = torch.pow(error,2)
        rmse = torch.sqrt(torch.mean(sqrt_error.contiguous().view(-1)))
        return rmse

class Loss_PSNR(nn.Module):
    def __init__(self):
        super(Loss_PSNR, self).__init__()

    def forward(self, img1, img2, data_range=255):
        img1 = img1.clamp(0., 1.).mul_(data_range).cpu().numpy()
        img2 = img2.clamp(0., 1.).mul_(data_range).cpu().numpy()
        img1 = img1.astype(np.float64)
        img2 = img2.astype(np.float64)
        mse = np.mean((img1 - img2) ** 2)

        if mse == 0:
            return float('inf')
        psnr = 20 * math.log10(255.0 / math.sqrt(mse))

        return psnr




def calc_psnr(img1, img2, data_range=255):
    img1 = img1.clamp(0., 1.).mul_(data_range).cpu().numpy()
    img2 = img2.clamp(0., 1.).mul_(data_range).cpu().numpy()
    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)
    mse = np.mean((img1 - img2)**2)
    if mse == 0:
        return float('inf')
    return 20 * math.log10(255.0 / math.sqrt(mse))
class Loss_SSIM(nn.Module):
    def __init__(self):
        super(Loss_SSIM, self).__init__()
    def forward(self, outputs, label,data_range=255):
        #ssim_val1 = ssim(outputs,label)
        img1 = outputs.clamp(0., 1.).mul_(data_range).cpu().numpy()
        img2 = label.clamp(0., 1.).mul_(data_range).cpu().numpy()
        img1 = img1.astype(np.float64)
        img2 = img2.astype(np.float64)
        print(img1.shape)

        ssim_val =  structural_similarity(img2[0],img1[0],win_size=13,gaussian_weights=True,multichannel=True,data_range=1.0,K1=0.05,K2=0.04,sigma=0.5)

        print(ssim_val)

        return ssim_val









def my_summary(test_model, H = 500, W = 500, C = 13, N = 1):
    model = test_model.cuda()
    print(model)
    inputs = torch.randn((N, C, H, W)).cuda()

    n_param = sum([p.nelement() for p in model.parameters()])

    print(f'Params:{n_param}')